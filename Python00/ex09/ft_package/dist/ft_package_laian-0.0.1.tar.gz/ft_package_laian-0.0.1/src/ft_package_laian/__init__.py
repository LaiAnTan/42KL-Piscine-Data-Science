"""
A test module for ex09 in 42KL's Python Piscine.

Contains only a singular function, count_in_list.
"""
# flake8: noqa
# the above comment ignores flake8 for this specific file.
from .count_in_list import count_in_list