"""
A test module for ex09 in 42KL's Python Piscine.

Contains only a singular function, count_in_list.
"""
# flake8: noqa
# the above comment ignores flake8 for this specific file.
# this removes the need to run each function to remove flake8 error
from count_in_list import count_in_list